//funtion for the cipher
function cipher() {
    const input = document.getElementById('input').value;
    const shiftnum = parseInt(document.getElementById('shiftnum').value);
    const shift = document.getElementById('shift').value;
    const operation = document.getElementById('operation').value;
    let result = '';
  //encypt and decrpyt using the ceaserCipher thing
  //dont reinvent the wheel
    if (operation === 'encrypt') {
        result = caesarCipher(input, shiftnum, shift);
    } else if (operation === 'decrypt') {
        result = caesarCipher(input, shiftnum, shift, true);
    }
  
    document.getElementById('result').value = result;
 }
 //setting up a new function to now control the inputs
 function caesarCipher(str, shift, direction, isDecrypt = false) {
    //alphebet in uppercase and lowercase to then understand tthe words typed
    const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const lowerAlphabet = alphabet.toLowerCase();
    let result = '';
  //seeing if the user enters dycrpt
    if (isDecrypt) {
        shift = (shift * -1);
    }
    for (let i = 0; i < str.length; i++) {
        let char = str[i];
        // Check if the character is a letter
        if (alphabet.indexOf(char.toUpperCase()) !== -1) {
            
            let isLower = char === char.toLowerCase();
            let alphabetToUse = isLower ? lowerAlphabet : alphabet;
            let index = alphabetToUse.indexOf(char);
            // Wrap around the alphabet with mod and numbers yeahhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh
            //I am just coping cause I have been on an error for like 30 minutes
            let newIndex = (index + (direction === 'right' ? shift : -shift) + 26) % 26; 
            result += alphabetToUse[newIndex];
        } else {
            
            result += char;
        }
    }
    //prints the result
    return result;
 }